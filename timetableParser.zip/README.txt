YOU NEED NODE.JS TO RUN THIS TOOl

Run the script using "node parser.js"